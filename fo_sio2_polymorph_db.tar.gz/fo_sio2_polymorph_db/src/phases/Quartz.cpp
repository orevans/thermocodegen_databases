#include <math.h>
#include "phases/Quartz.h"

//-----------------------------------------------------------------------------
Quartz::Quartz()
: _name("Quartz"), _endmembers(std::vector<std::shared_ptr<EndMember> > {std::make_shared<B_Quartz_Cristobalite_polymorph_berman>() })
{
  // Set number of components
  C = _endmembers.size();

  // Assign vector of molecular weights for each component
  M = Quartz::get_M();
}
//-----------------------------------------------------------------------------
Quartz::~Quartz()
{
  // Do nothing
}
//-----------------------------------------------------------------------------
std::string Quartz::name() const
{
  return _name;
}
//-----------------------------------------------------------------------------
std::vector<std::shared_ptr<EndMember> > Quartz::endmembers() const
{
  return _endmembers;
}
//-----------------------------------------------------------------------------
std::vector<double> Quartz::get_M() const
{
  std::vector<double> M(C);

  for(int k = 0; k < C; k++)
  {
    M[k] = (*_endmembers[k]).molecular_weight();
  }
  return M;
}
//-----------------------------------------------------------------------------
double Quartz::G(
    const double &T, const double &P,
    const std::vector<double> &n) const
{
  double _G = (*_endmembers[0]).G(T, P)*n[0];
  return _G;
}
//-----------------------------------------------------------------------------
double Quartz::dGdT(
    const double &T, const double &P,
    const std::vector<double> &n) const
{
  double _dGdT = (*_endmembers[0]).dGdT(T, P)*n[0];
  return _dGdT;
}
//-----------------------------------------------------------------------------
double Quartz::dGdP(
    const double &T, const double &P,
    const std::vector<double> &n) const
{
  double _dGdP = (*_endmembers[0]).dGdP(T, P)*n[0];
  return _dGdP;
}
//-----------------------------------------------------------------------------
double Quartz::d2GdT2(
    const double &T, const double &P,
    const std::vector<double> &n) const
{
  double _d2GdT2 = (*_endmembers[0]).d2GdT2(T, P)*n[0];
  return _d2GdT2;
}
//-----------------------------------------------------------------------------
double Quartz::d2GdTdP(
    const double &T, const double &P,
    const std::vector<double> &n) const
{
  double _d2GdTdP = (*_endmembers[0]).d2GdTdP(T, P)*n[0];
  return _d2GdTdP;
}
//-----------------------------------------------------------------------------
double Quartz::d2GdP2(
    const double &T, const double &P,
    const std::vector<double> &n) const
{
  double _d2GdP2 = (*_endmembers[0]).d2GdP2(T, P)*n[0];
  return _d2GdP2;
}
//-----------------------------------------------------------------------------
std::vector<double> Quartz::mu(
    const double &T, const double &P,
    const std::vector<double> &x) const
{
  std::vector<double> _mu = {
  (*_endmembers[0]).G(T, P)};
  return _mu;
}
//-----------------------------------------------------------------------------
std::vector<double> Quartz::dmu_dT(
    const double &T, const double &P,
    const std::vector<double> &x) const
{
  std::vector<double> _dmu_dT = {
  (*_endmembers[0]).dGdT(T, P)};
  return _dmu_dT;
}
//-----------------------------------------------------------------------------
std::vector<double> Quartz::dmu_dP(
    const double &T, const double &P,
    const std::vector<double> &x) const
{
  std::vector<double> _dmu_dP = {
  (*_endmembers[0]).dGdP(T, P)};
  return _dmu_dP;
}
//-----------------------------------------------------------------------------
std::vector<double> Quartz::dmu_dxi(
    const double &T, const double &P,
    const std::vector<double> &x, const int &i) const
{
  std::vector<double> _dx_dxi = dx_dxi(x, i);

  std::vector<double> _dmu_dxi = {
  0};
  return _dmu_dxi;
}
//-----------------------------------------------------------------------------
std::vector<double> Quartz::d2mu_dPdxi(
    const double &T, const double &P,
    const std::vector<double> &x, const int &i) const
{
  std::vector<double> _dx_dxi = dx_dxi(x, i);

  std::vector<double> _d2mu_dPdxi = {
  0};
  return _d2mu_dPdxi;
}
//-----------------------------------------------------------------------------
std::vector<double> Quartz::dmu_dci(
    const double &T, const double &P,
    const std::vector<double> &c, const int &i) const
{
  std::vector<double> _dmu_dci(C);
  std::vector<double> x = c_to_x(c);
  std::vector<double> _dmu_dxi = dmu_dxi(T, P, x, i);
  double dxi_dci = dxk_dcl(c, i, i);

  for(int k = 0; k < C; k++)
  {
    _dmu_dci[k] = _dmu_dxi[k]*dxi_dci;
  }
  return _dmu_dci;
}
//-----------------------------------------------------------------------------
std::vector<double> Quartz::d2mu_dPdci(
    const double &T, const double &P,
    const std::vector<double> &c, const int &i) const
{
  std::vector<double> _d2mu_dPdci(C);
  std::vector<double> x = c_to_x(c);
  std::vector<double> _d2mu_dPdxi = d2mu_dPdxi(T, P, x, i);
  double dxi_dci = dxk_dcl(c, i, i);

  for(int k = 0; k < C; k++)
  {
    _d2mu_dPdci[k] = _d2mu_dPdxi[k]*dxi_dci;
  }
  return _d2mu_dPdci;
}
//-----------------------------------------------------------------------------
double Quartz::V(
    const double &T, const double &P,
    const std::vector<double> &c) const
{
  std::vector<double> x = c_to_x(c);
  double _V = dGdP(T, P, x);
  return _V;
}
//-----------------------------------------------------------------------------
double Quartz::s(
    const double &T, const double &P,
    const std::vector<double> &c) const
{
  std::vector<double> x = c_to_x(c);
  double _s = -dGdT(T, P, x);
  return _s;
}
//-----------------------------------------------------------------------------
double Quartz::alpha(
    const double &T, const double &P,
    const std::vector<double> &c) const
{
  std::vector<double> x = c_to_x(c);
  double _alpha = d2GdTdP(T, P, x)/dGdP(T, P, x);
  return _alpha;
}
//-----------------------------------------------------------------------------
double Quartz::Cp(
    const double &T, const double &P,
    const std::vector<double> &c) const
{
  std::vector<double> x = c_to_x(c);
  double _Cp = -T*d2GdT2(T, P, x);
  return _Cp;
}
//-----------------------------------------------------------------------------
double Quartz::rho(
    const double &T, const double &P,
    const std::vector<double> &c) const
{
  std::vector<double> x = c_to_x(c);
  double _rho = 0.;

  for(int k = 0; k < C; k++)
  {
    _rho += x[k]*M[k];
  }
  _rho /= dGdP(T, P, x);

  return _rho;
}
//-----------------------------------------------------------------------------
double Quartz::drho_dT(
    const double &T, const double &P,
    const std::vector<double> &c) const
{
  std::vector<double> x = c_to_x(c);
  double _drho_dT = 0.;
  double _V = V(T, P, x);

  for(int k = 0; k < C; k++)
  {
    _drho_dT += x[k]*M[k];
  }
  _drho_dT *= -d2GdTdP(T, P, x)/(_V*_V);

  return _drho_dT;
}
//-----------------------------------------------------------------------------
double Quartz::drho_dP(
    const double &T, const double &P,
    const std::vector<double> &c) const
{
  std::vector<double> x = c_to_x(c);
  double _drho_dP = 0.;
  double _V = V(T, P, x);

  for(int k = 0; k < C; k++)
  {
    _drho_dP += x[k]*M[k];
  }
  _drho_dP *= -d2GdP2(T, P, x)/(_V*_V);

  return _drho_dP;
}
//-----------------------------------------------------------------------------
double Quartz::drho_dci(
    const double &T, const double &P,
    const std::vector<double> &c,
    const int &i) const
{
  double _drho_dci = 0.;
  std::vector<double> x = c_to_x(c);
  std::vector<double> dc_dci = dx_dxi(c, i);
  std::vector<double> _dmu_dP = dmu_dP(T, P, x);

  // Volume and its derivative with c[i]
  double _V = V(T, P, x);
  double _dV_dci = _dmu_dP[i]*dxk_dcl(c, i, i); // This should probably be summed over all components

  for(int k = 0; k < C; k++)
  {
    _drho_dci += dxk_dcl(c, k, i)*M[k]/_V - x[k]*M[k]/(_V*_V)*_dV_dci;
  }
  return _drho_dci;
}
//-----------------------------------------------------------------------------
std::vector<double> Quartz::dx_dxi(
    const std::vector<double> &x,
    const double &i) const
{
  double epsilon = 1.e-4;
  std::vector<double> _dx_dxi(C);
  if((1. - x[i]) > epsilon)
  {
    for(int k = 0; k < C; k++)
    {
      _dx_dxi[k] = -x[k]/(1. - x[i]);
    }
    // Fix dx_k/dx_i = 1 for k = i
    _dx_dxi[i] = 1.;
    }
  else
  {
    std::fill(_dx_dxi.begin(), _dx_dxi.end(), -1./(C - 1.));
    _dx_dxi[i] = 1.;
  }
  return _dx_dxi;
}
//-----------------------------------------------------------------------------
std::vector<double> Quartz::c_to_x(const std::vector<double> &c) const
{
  double sum_c_invM = 0.0;
  for(int i = 0; i < C; i++)
  {
    sum_c_invM += c[i]/M[i];
  }

  std::vector<double> x(C);
  for(int i = 0; i < C; i++)
  {
    x[i] = (c[i]/M[i])/sum_c_invM;
  }
  return x;
}
//-----------------------------------------------------------------------------
std::vector<double> Quartz::x_to_c(const std::vector<double> &x) const
{
  double sum_x_M = 0.0;
  for(int i = 0; i < C; i++)
  {
    sum_x_M += x[i]*M[i];
  }

  std::vector<double> c(C);
  for(int i = 0; i < C; i++)
  {
    c[i] = (x[i]*M[i])/sum_x_M;
  }
  return c;
}
//-----------------------------------------------------------------------------
double Quartz::dxk_dcl(const std::vector<double> &c,
    const int &k, const int &l) const
{
  double _dxk_dcl;
  double sum_c_invM = 0;
  for(int i = 0; i < C; i++)
  {
    sum_c_invM += c[i]/M[i];
  }

  double inv_Mk_sum_c_invM = (1./M[k])/sum_c_invM;
  double xk = c[k]*inv_Mk_sum_c_invM;
  std::vector<double> dc_dck = dx_dxi(c, l);

  double sum_dcdk_invM = 0;
  for(int i = 0; i < C; i++)
  {
    sum_dcdk_invM += dc_dck[i]/M[i];
  }

  double Mk_sum_cinvM_dck = M[k]*sum_dcdk_invM;

  if(l == k)
  {
    _dxk_dcl = inv_Mk_sum_c_invM*(1. - xk*Mk_sum_cinvM_dck);
  }
  else
  {
    _dxk_dcl = -inv_Mk_sum_c_invM*xk*Mk_sum_cinvM_dck;
  }

  return _dxk_dcl;
}
//-----------------------------------------------------------------------------
