#include <math.h>
#include <string>
#include <map>
#include "endmembers/Protoenstatite_berman.h"

//-----------------------------------------------------------------------------
Protoenstatite_berman::Protoenstatite_berman()  
{
  // do nothing;
}
//-----------------------------------------------------------------------------
Protoenstatite_berman::~Protoenstatite_berman()
{
  // Do nothing
}
//-----------------------------------------------------------------------------
std::string Protoenstatite_berman::name()
{
  return "Protoenstatite_berman";
}
//-----------------------------------------------------------------------------
std::string Protoenstatite_berman::formula()
{
  return "MgSiO3";
}
//-----------------------------------------------------------------------------
double Protoenstatite_berman::molecular_weight()
{
  return 100.3887;
}
//-----------------------------------------------------------------------------
double Protoenstatite_berman::G(const double &T, const double &P)
{
  double result = -1.2151015999999999e-6*((P)*(P)) + 3.7931399999999999e-8*P*((T)*(T)) + 3.1949877580000004e-5*P*T + 3.2291047222365066*P - 4802.3519999999999*pow(T, 1.0/2.0) - 3.7931399999999999e-8*((T)*(T)) - 166.5795*T*std::log(T) + 1196.5660739745351*T - 1558211.7465981543 + 1135280.0/T - 46525056.0/((T)*(T));
  return result;
}
//-----------------------------------------------------------------------------
double Protoenstatite_berman::dGdT(const double &T, const double &P)
{
  double result = 7.5862799999999998e-8*P*T + 3.1949877580000004e-5*P - 7.5862799999999998e-8*T - 166.5795*std::log(T) + 1029.9865739745351 - 1135280.0/((T)*(T)) + 93050112.0/((T)*(T)*(T)) - 2401.1759999999999/pow(T, 1.0/2.0);
  return result;
}
//-----------------------------------------------------------------------------
double Protoenstatite_berman::dGdP(const double &T, const double &P)
{
  double result = -2.4302031999999998e-6*P + 3.7931399999999999e-8*((T)*(T)) + 3.1949877580000004e-5*T + 3.2291047222365066;
  return result;
}
//-----------------------------------------------------------------------------
double Protoenstatite_berman::d2GdT2(const double &T, const double &P)
{
  double result = 7.5862799999999998e-8*P - 7.5862799999999998e-8 - 166.5795/T + 2270560.0/((T)*(T)*(T)) - 279150336.0/((T)*(T)*(T)*(T)) + 1200.588/pow(T, 3.0/2.0);
  return result;
}
//-----------------------------------------------------------------------------
double Protoenstatite_berman::d2GdTdP(const double &T, const double &P)
{
  double result = 7.5862799999999998e-8*T + 3.1949877580000004e-5;
  return result;
}
//-----------------------------------------------------------------------------
double Protoenstatite_berman::d2GdP2(const double &T, const double &P)
{
  double result = -2.4302031999999998e-6;
  return result;
}
//-----------------------------------------------------------------------------
double Protoenstatite_berman::d3GdT3(const double &T, const double &P)
{
  double result = 166.5795/((T)*(T)) - 6811680.0/((T)*(T)*(T)*(T)) + 1116601344.0/pow(T, 5) - 1800.8820000000001/pow(T, 5.0/2.0);
  return result;
}
//-----------------------------------------------------------------------------
double Protoenstatite_berman::d3GdT2dP(const double &T, const double &P)
{
  double result = 7.5862799999999998e-8;
  return result;
}
//-----------------------------------------------------------------------------
double Protoenstatite_berman::d3GdTdP2(const double &T, const double &P)
{
  double result = 0;
  return result;
}
//-----------------------------------------------------------------------------
double Protoenstatite_berman::d3GdP3(const double &T, const double &P)
{
  double result = 0;
  return result;
}
//-----------------------------------------------------------------------------
double Protoenstatite_berman::S(const double& T, const double& P)
{
  double result = -Protoenstatite_berman::dGdT(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Protoenstatite_berman::V(const double& T, const double& P)
{
  double result = Protoenstatite_berman::dGdP(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Protoenstatite_berman::dVdT(const double& T, const double& P)
{
  double result = Protoenstatite_berman::d2GdTdP(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Protoenstatite_berman::dVdP(const double& T, const double& P)
{
  double result = Protoenstatite_berman::d2GdP2(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Protoenstatite_berman::Cv(const double& T, const double& P)
{
  double result = -T*Protoenstatite_berman::d2GdT2(T, P);
  double dVdT = Protoenstatite_berman::d2GdTdP(T, P);
  double dVdP = Protoenstatite_berman::d2GdP2(T, P);
  result += T*dVdT*dVdT/dVdP;
  return result;
}
//-----------------------------------------------------------------------------
double Protoenstatite_berman::Cp(const double& T, const double& P)
{
  double result = -T*Protoenstatite_berman::d2GdT2(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Protoenstatite_berman::dCpdT(const double& T, const double& P)
{
  double result = -T*Protoenstatite_berman::d3GdT3(T, P) - Protoenstatite_berman::d2GdT2(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Protoenstatite_berman::alpha(const double& T, const double& P)
{
  double result = Protoenstatite_berman::d2GdTdP(T, P)/Protoenstatite_berman::dGdP(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Protoenstatite_berman::beta(const double& T, const double& P)
{
  double result = -Protoenstatite_berman::d2GdP2(T, P)/Protoenstatite_berman::dGdP(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Protoenstatite_berman::K(const double& T, const double& P)
{
  double result = -Protoenstatite_berman::dGdP(T,P)/Protoenstatite_berman::d2GdP2(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Protoenstatite_berman::Kp(const double& T, const double& P)
{
  double result = -Protoenstatite_berman::dGdP(T, P)/Protoenstatite_berman::d2GdP2(T, P);
  return result;
}
//-----------------------------------------------------------------------------
void Protoenstatite_berman::set_parameter(const std::string& p, const double& val)
{
  *parameters[p] = val;
}
//-----------------------------------------------------------------------------
void Protoenstatite_berman::get_parameter(const std::string& p)
{
  std::cout << p << " = " << *parameters[p] << std::endl;
}
//-----------------------------------------------------------------------------
void Protoenstatite_berman::list_active_parameters()
{
  std::cout << "Active parameters: \n" << std::endl;
  for (auto const& x : parameters)
  {
    std::cout << x.first << " = "  << *x.second << std::endl;
  }
}
//-----------------------------------------------------------------------------

