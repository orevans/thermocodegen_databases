#include <math.h>
#include "phases/Liquid.h"

//-----------------------------------------------------------------------------
Liquid::Liquid()
: _name("Liquid"), _endmembers(std::vector<std::shared_ptr<EndMember> > {std::make_shared<Quartz4_liquid>(),std::make_shared<Forsterite_xmelts>() })
{
  // Assign vector of molecular weights for each component
  M = Liquid::get_M();
}
//-----------------------------------------------------------------------------
Liquid::~Liquid()
{
  // Do nothing
}
//-----------------------------------------------------------------------------
std::string Liquid::name() const
{
  return _name;
}
//-----------------------------------------------------------------------------
std::vector<std::shared_ptr<EndMember> > Liquid::endmembers() const
{
  return _endmembers;
}
//-----------------------------------------------------------------------------
std::vector<double> Liquid::get_M() const
{
  int C = _endmembers.size();
  std::vector<double> M(C);

  for(int k = 0; k < C; k++)
  {
    M[k] = (*_endmembers[k]).molecular_weight();
  }
  return M;
}
//-----------------------------------------------------------------------------
double Liquid::G(const double &T, const double &P,
                       const std::vector<double> &n) const
{
  double _G = (-((0.54120000000000001*P + 10668.0)*(n[0] + n[1]) - (1.3371*P + 45836.0)*(n[0] - n[1]))*n[0]*n[1] + ((n[0] + n[1])*(n[0] + n[1]))*(8.3142999999999994*T*(std::log(n[0]/(n[0] + n[1]))*n[0] + std::log(n[1]/(n[0] + n[1]))*n[1]) + (*_endmembers[0]).G(T, P)*n[0] + (*_endmembers[1]).G(T, P)*n[1]))/((n[0] + n[1])*(n[0] + n[1]));
  return _G;
}
//-----------------------------------------------------------------------------
std::vector<double> Liquid::mu(const double &T, const double &P,
                                     const std::vector<double> &x) const
{
  std::vector<double> _mu = {
  8.3142999999999994*T*std::log(x[0]) + x[0]*x[1]*(0.79589999999999994*P + 35168.0) + 2*x[0]*x[1]*(0.54120000000000001*P - (1.3371*P + 45836.0)*(x[0] - x[1]) + 10668.0) - x[1]*(0.54120000000000001*P - (1.3371*P + 45836.0)*(x[0] - x[1]) + 10668.0) + (*_endmembers[0]).G(T, P),
  8.3142999999999994*T*std::log(x[1]) - x[0]*x[1]*(1.8782999999999999*P + 56504.0) + 2*x[0]*x[1]*(0.54120000000000001*P - (1.3371*P + 45836.0)*(x[0] - x[1]) + 10668.0) - x[0]*(0.54120000000000001*P - (1.3371*P + 45836.0)*(x[0] - x[1]) + 10668.0) + (*_endmembers[1]).G(T, P)};
  return _mu;
}
//-----------------------------------------------------------------------------
std::vector<double> Liquid::dmu_dT(const double &T, const double &P,
                                         const std::vector<double> &x) const
{
  std::vector<double> _dmu_dT = {
  8.3142999999999994*std::log(x[0]) + (*_endmembers[0]).dGdT(T, P),
  8.3142999999999994*std::log(x[1]) + (*_endmembers[1]).dGdT(T, P)};
  return _dmu_dT;
}
//-----------------------------------------------------------------------------
std::vector<double> Liquid::dmu_dP(const double &T, const double &P,
                                         const std::vector<double> &x) const
{
  std::vector<double> _dmu_dP = {
  2*x[0]*x[1]*(-1.3371*x[0] + 1.3371*x[1] + 0.54120000000000001) + 0.79589999999999994*x[0]*x[1] - x[1]*(-1.3371*x[0] + 1.3371*x[1] + 0.54120000000000001) + (*_endmembers[0]).dGdP(T, P),
  2*x[0]*x[1]*(-1.3371*x[0] + 1.3371*x[1] + 0.54120000000000001) - 1.8782999999999999*x[0]*x[1] - x[0]*(-1.3371*x[0] + 1.3371*x[1] + 0.54120000000000001) + (*_endmembers[1]).dGdP(T, P)};
  return _dmu_dP;
}
//-----------------------------------------------------------------------------
std::vector<double> Liquid::dmu_dxi(const double &T, const double &P,
                                          const std::vector<double> &x,
                                          const int &i) const
{
  std::vector<double> _dx_dxi = Liquid::dx_dxi(x, i);

  std::vector<double> _dmu_dxi = {
  _dx_dxi[0]*(8.3142999999999994*T/x[0] + 2*x[0]*x[1]*(-1.3371*P - 45836.0) - x[1]*(-1.3371*P - 45836.0) + x[1]*(0.79589999999999994*P + 35168.0) + 2*x[1]*(0.54120000000000001*P - (1.3371*P + 45836.0)*(x[0] - x[1]) + 10668.0)) + _dx_dxi[1]*(-0.54120000000000001*P + 2*x[0]*x[1]*(1.3371*P + 45836.0) + x[0]*(0.79589999999999994*P + 35168.0) + 2*x[0]*(0.54120000000000001*P - (1.3371*P + 45836.0)*(x[0] - x[1]) + 10668.0) - x[1]*(1.3371*P + 45836.0) + (1.3371*P + 45836.0)*(x[0] - x[1]) - 10668.0),
  _dx_dxi[0]*(-0.54120000000000001*P + 2*x[0]*x[1]*(-1.3371*P - 45836.0) - x[0]*(-1.3371*P - 45836.0) - x[1]*(1.8782999999999999*P + 56504.0) + 2*x[1]*(0.54120000000000001*P - (1.3371*P + 45836.0)*(x[0] - x[1]) + 10668.0) + (1.3371*P + 45836.0)*(x[0] - x[1]) - 10668.0) + _dx_dxi[1]*(8.3142999999999994*T/x[1] + 2*x[0]*x[1]*(1.3371*P + 45836.0) - x[0]*(1.3371*P + 45836.0) - x[0]*(1.8782999999999999*P + 56504.0) + 2*x[0]*(0.54120000000000001*P - (1.3371*P + 45836.0)*(x[0] - x[1]) + 10668.0))};
  return _dmu_dxi;
}
//-----------------------------------------------------------------------------
std::vector<double> Liquid::dmu_dci(const double &T, const double &P,
                                          const std::vector<double> &c,
                                          const int &i) const
{
  int C = c.size();
  std::vector<double> _dmu_dci(C);
  std::vector<double> x = Liquid::c_to_x(c);
  std::vector<double> dmu_dxi = Liquid::dmu_dxi(T, P, x, i);
  double dxi_dci = Liquid::dxk_dck(c, i);

  for(int k = 0; k < C; k++)
  {
    _dmu_dci[k] = dmu_dxi[k]*dxi_dci;
  }
  return _dmu_dci;
}
//-----------------------------------------------------------------------------
double Liquid::s(const double &T, const double &P,
                       const std::vector<double> &c) const
{
  double _s = -8.3142999999999994*c[1]*std::log(c[1]/(M[1]*(c[1]/M[1] + c[0]/M[0])))/M[1] - c[1]*(*_endmembers[1]).dGdT(T, P)/M[1] - 8.3142999999999994*c[0]*std::log(c[0]/(M[0]*(c[1]/M[1] + c[0]/M[0])))/M[0] - c[0]*(*_endmembers[0]).dGdT(T, P)/M[0];
  return _s;
}
//-----------------------------------------------------------------------------
double Liquid::alpha(const double &T, const double &P,
                           const std::vector<double> &c) const
{
  double _alpha = c[0]*(*_endmembers[0]).alpha(T, P) + c[1]*(*_endmembers[1]).alpha(T, P);
  return _alpha;
}
//-----------------------------------------------------------------------------
double Liquid::Cp(const double &T, const double &P,
                        const std::vector<double> &c) const
{
  double _Cp = c[1]*(*_endmembers[1]).Cp(T, P)/M[1] + c[0]*(*_endmembers[0]).Cp(T, P)/M[0];
  return _Cp;
}
//-----------------------------------------------------------------------------
double Liquid::rho(const double &T, const double &P,
                         const std::vector<double> &c) const
{
  double _rho = 1.0/(c[1]*(*_endmembers[1]).V(T, P)/M[1] + c[0]*(*_endmembers[0]).V(T, P)/M[0]);
  return _rho;
}
//-----------------------------------------------------------------------------
double Liquid::drho_dT(const double &T, const double &P,
                             const std::vector<double> &c) const
{
  double _drho_dT = 1.0*(-c[1]*(*_endmembers[1]).dVdT(T, P)/M[1] - c[0]*(*_endmembers[0]).dVdT(T, P)/M[0])/((c[1]*(*_endmembers[1]).V(T, P)/M[1] + c[0]*(*_endmembers[0]).V(T, P)/M[0])*(c[1]*(*_endmembers[1]).V(T, P)/M[1] + c[0]*(*_endmembers[0]).V(T, P)/M[0]));
  return _drho_dT;
}
//-----------------------------------------------------------------------------
double Liquid::drho_dP(const double &T, const double &P,
                             const std::vector<double> &c) const
{
  double _drho_dP = 1.0*(-c[1]*(*_endmembers[1]).dVdP(T, P)/M[1] - c[0]*(*_endmembers[0]).dVdP(T, P)/M[0])/((c[1]*(*_endmembers[1]).V(T, P)/M[1] + c[0]*(*_endmembers[0]).V(T, P)/M[0])*(c[1]*(*_endmembers[1]).V(T, P)/M[1] + c[0]*(*_endmembers[0]).V(T, P)/M[0]));
  return _drho_dP;
}
//-----------------------------------------------------------------------------
double Liquid::drho_dci(const double &T, const double &P,
                              const std::vector<double> &c,
                              const int &i) const
{
  int C = c.size();
  std::vector<double> dc_dci = Liquid::dx_dxi(c, i);
  double _drho_dci = 0.;

  for(int k = 0; k < C; k++)
  {
    _drho_dci += dc_dci[k]*(*_endmembers[k]).V(T, P)/M[k];
  }
  _drho_dci *= -pow(Liquid::rho(T, P, c), 2);
  return _drho_dci;
}
//-----------------------------------------------------------------------------
std::vector<double> Liquid::dx_dxi(const std::vector<double> &x,
                                         const double &i) const
{
  double epsilon = 1.e-4;
  double C = x.size();
  std::vector<double> _dx_dxi(C);
  if((1. - x[i]) > epsilon)
  {
    for(int k = 0; k < C; k++)
    {
      _dx_dxi[k] = -x[k]/(1. - x[i]);
    }
    // Fix dx_k/dx_i = 1 for k = i
    _dx_dxi[i] = 1.;
    }
  else
  {
    std::fill(_dx_dxi.begin(), _dx_dxi.end(), -1./(C - 1.));
    _dx_dxi[i] = 1.;
  }
  return _dx_dxi;
}
//-----------------------------------------------------------------------------
std::vector<double> Liquid::c_to_x(const std::vector<double> &c) const
{
  int C = c.size();

  double sum_c_invM = 0.0;
  for(int i = 0; i < C; i++)
  {
    sum_c_invM += c[i]/M[i];
  }

  std::vector<double> x(C);
  for(int i = 0; i < C; i++)
  {
    x[i] = (c[i]/M[i])/sum_c_invM;
  }
  return x;
}
//-----------------------------------------------------------------------------
std::vector<double> Liquid::x_to_c(const std::vector<double> &x) const
{
  int C = x.size();

  double sum_x_M = 0.0;
  for(int i = 0; i < C; i++)
  {
    sum_x_M += x[i]*M[i];
  }

  std::vector<double> c(C);
  for(int i = 0; i < C; i++)
  {
    c[i] = (x[i]*M[i])/sum_x_M;
  }
  return c;
}
//-----------------------------------------------------------------------------
double Liquid::dxk_dck(const std::vector<double> &c, const int &k) const
{
  double sum_c_invM = 0;
  for(int i = 0; i < c.size(); i++)
  {
    sum_c_invM += c[i]/M[i];
  }

  double inv_Mk_sum_c_invM = (1./M[k])/sum_c_invM;
  double xk = c[k]*inv_Mk_sum_c_invM;
  std::vector<double> dc_dck = Liquid::dx_dxi(c, k);

  double sum_dcdk_invM = 0;
  for(int i = 0; i < c.size(); i++)
  {
    sum_dcdk_invM += dc_dck[i]/M[i];
  }

  double Mk_sum_cinvM_dck = M[k]*sum_dcdk_invM;
  return inv_Mk_sum_c_invM*(1. - xk*Mk_sum_cinvM_dck);
}
//-----------------------------------------------------------------------------
