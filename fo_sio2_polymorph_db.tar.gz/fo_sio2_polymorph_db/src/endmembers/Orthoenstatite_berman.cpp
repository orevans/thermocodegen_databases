#include <math.h>
#include <string>
#include <map>
#include "endmembers/Orthoenstatite_berman.h"

//-----------------------------------------------------------------------------
Orthoenstatite_berman::Orthoenstatite_berman()  
{
  // do nothing;
}
//-----------------------------------------------------------------------------
Orthoenstatite_berman::~Orthoenstatite_berman()
{
  // Do nothing
}
//-----------------------------------------------------------------------------
std::string Orthoenstatite_berman::name()
{
  return "Orthoenstatite_berman";
}
//-----------------------------------------------------------------------------
std::string Orthoenstatite_berman::formula()
{
  return "MgSiO3";
}
//-----------------------------------------------------------------------------
double Orthoenstatite_berman::molecular_weight()
{
  return 100.3887;
}
//-----------------------------------------------------------------------------
double Orthoenstatite_berman::G(const double &T, const double &P)
{
  double result = 4.6681699999999991e-13*((P)*(P)*(P)) - 1.1737798504509998e-6*((P)*(P)) + 2.3394111e-8*P*((T)*(T)) + 6.3296713010699987e-5*P*T + 3.1120508499810255*P - 4802.3519999999999*pow(T, 1.0/2.0) - 2.3394111e-8*((T)*(T)) - 166.5795*T*std::log(T) + 1197.8340426276998*T - 1559805.2395443236 + 1135280.0/T - 46525056.0/((T)*(T));
  return result;
}
//-----------------------------------------------------------------------------
double Orthoenstatite_berman::dGdT(const double &T, const double &P)
{
  double result = 4.6788222e-8*P*T + 6.3296713010699987e-5*P - 4.6788222e-8*T - 166.5795*std::log(T) + 1031.2545426276997 - 1135280.0/((T)*(T)) + 93050112.0/((T)*(T)*(T)) - 2401.1759999999999/pow(T, 1.0/2.0);
  return result;
}
//-----------------------------------------------------------------------------
double Orthoenstatite_berman::dGdP(const double &T, const double &P)
{
  double result = 1.4004509999999997e-12*((P)*(P)) - 2.3475597009019996e-6*P + 2.3394111e-8*((T)*(T)) + 6.3296713010699987e-5*T + 3.1120508499810255;
  return result;
}
//-----------------------------------------------------------------------------
double Orthoenstatite_berman::d2GdT2(const double &T, const double &P)
{
  double result = 4.6788222e-8*P - 4.6788222e-8 - 166.5795/T + 2270560.0/((T)*(T)*(T)) - 279150336.0/((T)*(T)*(T)*(T)) + 1200.588/pow(T, 3.0/2.0);
  return result;
}
//-----------------------------------------------------------------------------
double Orthoenstatite_berman::d2GdTdP(const double &T, const double &P)
{
  double result = 4.6788222e-8*T + 6.3296713010699987e-5;
  return result;
}
//-----------------------------------------------------------------------------
double Orthoenstatite_berman::d2GdP2(const double &T, const double &P)
{
  double result = 2.8009019999999994e-12*P - 2.3475597009019996e-6;
  return result;
}
//-----------------------------------------------------------------------------
double Orthoenstatite_berman::d3GdT3(const double &T, const double &P)
{
  double result = 166.5795/((T)*(T)) - 6811680.0/((T)*(T)*(T)*(T)) + 1116601344.0/pow(T, 5) - 1800.8820000000001/pow(T, 5.0/2.0);
  return result;
}
//-----------------------------------------------------------------------------
double Orthoenstatite_berman::d3GdT2dP(const double &T, const double &P)
{
  double result = 4.6788222e-8;
  return result;
}
//-----------------------------------------------------------------------------
double Orthoenstatite_berman::d3GdTdP2(const double &T, const double &P)
{
  double result = 0;
  return result;
}
//-----------------------------------------------------------------------------
double Orthoenstatite_berman::d3GdP3(const double &T, const double &P)
{
  double result = 2.8009019999999994e-12;
  return result;
}
//-----------------------------------------------------------------------------
double Orthoenstatite_berman::S(const double& T, const double& P)
{
  double result = -Orthoenstatite_berman::dGdT(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Orthoenstatite_berman::V(const double& T, const double& P)
{
  double result = Orthoenstatite_berman::dGdP(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Orthoenstatite_berman::dVdT(const double& T, const double& P)
{
  double result = Orthoenstatite_berman::d2GdTdP(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Orthoenstatite_berman::dVdP(const double& T, const double& P)
{
  double result = Orthoenstatite_berman::d2GdP2(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Orthoenstatite_berman::Cv(const double& T, const double& P)
{
  double result = -T*Orthoenstatite_berman::d2GdT2(T, P);
  double dVdT = Orthoenstatite_berman::d2GdTdP(T, P);
  double dVdP = Orthoenstatite_berman::d2GdP2(T, P);
  result += T*dVdT*dVdT/dVdP;
  return result;
}
//-----------------------------------------------------------------------------
double Orthoenstatite_berman::Cp(const double& T, const double& P)
{
  double result = -T*Orthoenstatite_berman::d2GdT2(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Orthoenstatite_berman::dCpdT(const double& T, const double& P)
{
  double result = -T*Orthoenstatite_berman::d3GdT3(T, P) - Orthoenstatite_berman::d2GdT2(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Orthoenstatite_berman::alpha(const double& T, const double& P)
{
  double result = Orthoenstatite_berman::d2GdTdP(T, P)/Orthoenstatite_berman::dGdP(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Orthoenstatite_berman::beta(const double& T, const double& P)
{
  double result = -Orthoenstatite_berman::d2GdP2(T, P)/Orthoenstatite_berman::dGdP(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Orthoenstatite_berman::K(const double& T, const double& P)
{
  double result = -Orthoenstatite_berman::dGdP(T,P)/Orthoenstatite_berman::d2GdP2(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Orthoenstatite_berman::Kp(const double& T, const double& P)
{
  double result = -Orthoenstatite_berman::dGdP(T, P)/Orthoenstatite_berman::d2GdP2(T, P);
  return result;
}
//-----------------------------------------------------------------------------
void Orthoenstatite_berman::set_parameter(const std::string& p, const double& val)
{
  *parameters[p] = val;
}
//-----------------------------------------------------------------------------
void Orthoenstatite_berman::get_parameter(const std::string& p)
{
  std::cout << p << " = " << *parameters[p] << std::endl;
}
//-----------------------------------------------------------------------------
void Orthoenstatite_berman::list_active_parameters()
{
  std::cout << "Active parameters: \n" << std::endl;
  for (auto const& x : parameters)
  {
    std::cout << x.first << " = "  << *x.second << std::endl;
  }
}
//-----------------------------------------------------------------------------

