#include <math.h>
#include <string>
#include <map>
#include "endmembers/Fayalite_xmelts.h"

//-----------------------------------------------------------------------------
Fayalite_xmelts::Fayalite_xmelts()  
{
  // do nothing;
}
//-----------------------------------------------------------------------------
Fayalite_xmelts::~Fayalite_xmelts()
{
  // Do nothing
}
//-----------------------------------------------------------------------------
std::string Fayalite_xmelts::name()
{
  return "Fayalite_xmelts";
}
//-----------------------------------------------------------------------------
std::string Fayalite_xmelts::formula()
{
  return "Fe2SiO4";
}
//-----------------------------------------------------------------------------
double Fayalite_xmelts::molecular_weight()
{
  return 203.7731;
}
//-----------------------------------------------------------------------------
double Fayalite_xmelts::G(const double &T, const double &P)
{
  double result = 2.4333333333333332e-10*((P)*(P)*(P)) - ((P)*(P))*(5.7500000000000002e-9*T + 4.3301174999999989e-6) + P*(0.00058401150000000001*T + 4.4428890595050001) - T*(240.19999999999999*std::log(T) - 1268.3296505760113) + 240.19941599424999*T - 1533995.3831770408;
  return result;
}
//-----------------------------------------------------------------------------
double Fayalite_xmelts::dGdT(const double &T, const double &P)
{
  double result = -5.7500000000000002e-9*((P)*(P)) + 0.00058401150000000001*P - 240.19999999999999*std::log(T) + 1268.3290665702611;
  return result;
}
//-----------------------------------------------------------------------------
double Fayalite_xmelts::dGdP(const double &T, const double &P)
{
  double result = 7.2999999999999996e-10*((P)*(P)) + 2*P*(-5.7500000000000002e-9*T - 4.3301174999999989e-6) + 0.00058401150000000001*T + 4.4428890595050001;
  return result;
}
//-----------------------------------------------------------------------------
double Fayalite_xmelts::d2GdT2(const double &T, const double &P)
{
  double result = -240.19999999999999/T;
  return result;
}
//-----------------------------------------------------------------------------
double Fayalite_xmelts::d2GdTdP(const double &T, const double &P)
{
  double result = -1.15e-8*P + 0.00058401150000000001;
  return result;
}
//-----------------------------------------------------------------------------
double Fayalite_xmelts::d2GdP2(const double &T, const double &P)
{
  double result = 1.4599999999999999e-9*P - 1.15e-8*T - 8.6602349999999979e-6;
  return result;
}
//-----------------------------------------------------------------------------
double Fayalite_xmelts::d3GdT3(const double &T, const double &P)
{
  double result = 240.19999999999999/((T)*(T));
  return result;
}
//-----------------------------------------------------------------------------
double Fayalite_xmelts::d3GdT2dP(const double &T, const double &P)
{
  double result = 0;
  return result;
}
//-----------------------------------------------------------------------------
double Fayalite_xmelts::d3GdTdP2(const double &T, const double &P)
{
  double result = -1.15e-8;
  return result;
}
//-----------------------------------------------------------------------------
double Fayalite_xmelts::d3GdP3(const double &T, const double &P)
{
  double result = 1.4599999999999999e-9;
  return result;
}
//-----------------------------------------------------------------------------
double Fayalite_xmelts::S(const double& T, const double& P)
{
  double result = -Fayalite_xmelts::dGdT(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Fayalite_xmelts::V(const double& T, const double& P)
{
  double result = Fayalite_xmelts::dGdP(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Fayalite_xmelts::dVdT(const double& T, const double& P)
{
  double result = Fayalite_xmelts::d2GdTdP(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Fayalite_xmelts::dVdP(const double& T, const double& P)
{
  double result = Fayalite_xmelts::d2GdP2(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Fayalite_xmelts::Cv(const double& T, const double& P)
{
  double result = -T*Fayalite_xmelts::d2GdT2(T, P);
  double dVdT = Fayalite_xmelts::d2GdTdP(T, P);
  double dVdP = Fayalite_xmelts::d2GdP2(T, P);
  result += T*dVdT*dVdT/dVdP;
  return result;
}
//-----------------------------------------------------------------------------
double Fayalite_xmelts::Cp(const double& T, const double& P)
{
  double result = -T*Fayalite_xmelts::d2GdT2(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Fayalite_xmelts::dCpdT(const double& T, const double& P)
{
  double result = -T*Fayalite_xmelts::d3GdT3(T, P) - Fayalite_xmelts::d2GdT2(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Fayalite_xmelts::alpha(const double& T, const double& P)
{
  double result = Fayalite_xmelts::d2GdTdP(T, P)/Fayalite_xmelts::dGdP(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Fayalite_xmelts::beta(const double& T, const double& P)
{
  double result = -Fayalite_xmelts::d2GdP2(T, P)/Fayalite_xmelts::dGdP(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Fayalite_xmelts::K(const double& T, const double& P)
{
  double result = -Fayalite_xmelts::dGdP(T,P)/Fayalite_xmelts::d2GdP2(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Fayalite_xmelts::Kp(const double& T, const double& P)
{
  double result = -Fayalite_xmelts::dGdP(T, P)/Fayalite_xmelts::d2GdP2(T, P);
  return result;
}
//-----------------------------------------------------------------------------
void Fayalite_xmelts::set_parameter(const std::string& p, const double& val)
{
  *parameters[p] = val;
}
//-----------------------------------------------------------------------------
void Fayalite_xmelts::get_parameter(const std::string& p)
{
  std::cout << p << " = " << *parameters[p] << std::endl;
}
//-----------------------------------------------------------------------------
void Fayalite_xmelts::list_active_parameters()
{
  std::cout << "Active parameters: \n" << std::endl;
  for (auto const& x : parameters)
  {
    std::cout << x.first << " = "  << *x.second << std::endl;
  }
}
//-----------------------------------------------------------------------------

