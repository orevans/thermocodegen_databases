#include <math.h>
#include <string>
#include <map>
#include "endmembers/Forsterite_xmelts.h"

//-----------------------------------------------------------------------------
Forsterite_xmelts::Forsterite_xmelts()  
{
  // do nothing;
}
//-----------------------------------------------------------------------------
Forsterite_xmelts::~Forsterite_xmelts()
{
  // Do nothing
}
//-----------------------------------------------------------------------------
std::string Forsterite_xmelts::name()
{
  return "Forsterite_xmelts";
}
//-----------------------------------------------------------------------------
std::string Forsterite_xmelts::formula()
{
  return "Mg2SiO4";
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::molecular_weight()
{
  return 140.69310000000002;
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::G(const double &T, const double &P)
{
  double result = 6.9000000000000007e-11*((P)*(P)*(P)) - ((P)*(P))*(3.2500000000000002e-9*T + 1.3124694999999988e-6) + P*(0.0005240065000000001*T + 4.103272024732) - T*(271.0*std::log(T) - 1604.0690509917315) + 270.99947599675005*T - 2309449.9419540325;
  return result;
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::dGdT(const double &T, const double &P)
{
  double result = -3.2500000000000002e-9*((P)*(P)) + 0.0005240065000000001*P - 271.0*std::log(T) + 1604.0685269884816;
  return result;
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::dGdP(const double &T, const double &P)
{
  double result = 2.0700000000000001e-10*((P)*(P)) + 2*P*(-3.2500000000000002e-9*T - 1.3124694999999988e-6) + 0.0005240065000000001*T + 4.103272024732;
  return result;
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::d2GdT2(const double &T, const double &P)
{
  double result = -271.0/T;
  return result;
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::d2GdTdP(const double &T, const double &P)
{
  double result = -6.5000000000000003e-9*P + 0.0005240065000000001;
  return result;
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::d2GdP2(const double &T, const double &P)
{
  double result = 4.1400000000000002e-10*P - 6.5000000000000003e-9*T - 2.6249389999999975e-6;
  return result;
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::d3GdT3(const double &T, const double &P)
{
  double result = 271.0/((T)*(T));
  return result;
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::d3GdT2dP(const double &T, const double &P)
{
  double result = 0;
  return result;
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::d3GdTdP2(const double &T, const double &P)
{
  double result = -6.5000000000000003e-9;
  return result;
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::d3GdP3(const double &T, const double &P)
{
  double result = 4.1400000000000002e-10;
  return result;
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::S(const double& T, const double& P)
{
  double result = -Forsterite_xmelts::dGdT(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::V(const double& T, const double& P)
{
  double result = Forsterite_xmelts::dGdP(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::dVdT(const double& T, const double& P)
{
  double result = Forsterite_xmelts::d2GdTdP(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::dVdP(const double& T, const double& P)
{
  double result = Forsterite_xmelts::d2GdP2(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::Cv(const double& T, const double& P)
{
  double result = -T*Forsterite_xmelts::d2GdT2(T, P);
  double dVdT = Forsterite_xmelts::d2GdTdP(T, P);
  double dVdP = Forsterite_xmelts::d2GdP2(T, P);
  result += T*dVdT*dVdT/dVdP;
  return result;
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::Cp(const double& T, const double& P)
{
  double result = -T*Forsterite_xmelts::d2GdT2(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::dCpdT(const double& T, const double& P)
{
  double result = -T*Forsterite_xmelts::d3GdT3(T, P) - Forsterite_xmelts::d2GdT2(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::alpha(const double& T, const double& P)
{
  double result = Forsterite_xmelts::d2GdTdP(T, P)/Forsterite_xmelts::dGdP(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::beta(const double& T, const double& P)
{
  double result = -Forsterite_xmelts::d2GdP2(T, P)/Forsterite_xmelts::dGdP(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::K(const double& T, const double& P)
{
  double result = -Forsterite_xmelts::dGdP(T,P)/Forsterite_xmelts::d2GdP2(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::Kp(const double& T, const double& P)
{
  double result = -Forsterite_xmelts::dGdP(T, P)/Forsterite_xmelts::d2GdP2(T, P);
  return result;
}
//-----------------------------------------------------------------------------
void Forsterite_xmelts::set_parameter(const std::string& p, const double& val)
{
  *parameters[p] = val;
}
//-----------------------------------------------------------------------------
void Forsterite_xmelts::get_parameter(const std::string& p)
{
  std::cout << p << " = " << *parameters[p] << std::endl;
}
//-----------------------------------------------------------------------------
void Forsterite_xmelts::list_active_parameters()
{
  std::cout << "Active parameters: \n" << std::endl;
  for (auto const& x : parameters)
  {
    std::cout << x.first << " = "  << *x.second << std::endl;
  }
}
//-----------------------------------------------------------------------------

