#include <math.h>
#include "phases/Olivine.h"

//-----------------------------------------------------------------------------
Olivine::Olivine()
: _name("Olivine"), _endmembers(std::vector<std::shared_ptr<EndMember> > {std::make_shared<Forsterite_berman>() })
{
  // Assign vector of molecular weights for each component
  M = Olivine::get_M();
}
//-----------------------------------------------------------------------------
Olivine::~Olivine()
{
  // Do nothing
}
//-----------------------------------------------------------------------------
std::string Olivine::name() const
{
  return _name;
}
//-----------------------------------------------------------------------------
std::vector<std::shared_ptr<EndMember> > Olivine::endmembers() const
{
  return _endmembers;
}
//-----------------------------------------------------------------------------
std::vector<double> Olivine::get_M() const
{
  int C = _endmembers.size();
  std::vector<double> M(C);

  for(int k = 0; k < C; k++)
  {
    M[k] = (*_endmembers[k]).molecular_weight();
  }
  return M;
}
//-----------------------------------------------------------------------------
double Olivine::G(const double &T, const double &P,
                       const std::vector<double> &n) const
{
  double _G = (*_endmembers[0]).G(T, P)*n[0];
  return _G;
}
//-----------------------------------------------------------------------------
std::vector<double> Olivine::mu(const double &T, const double &P,
                                     const std::vector<double> &x) const
{
  std::vector<double> _mu = {
  (*_endmembers[0]).G(T, P)};
  return _mu;
}
//-----------------------------------------------------------------------------
std::vector<double> Olivine::dmu_dT(const double &T, const double &P,
                                         const std::vector<double> &x) const
{
  std::vector<double> _dmu_dT = {
  (*_endmembers[0]).dGdT(T, P)};
  return _dmu_dT;
}
//-----------------------------------------------------------------------------
std::vector<double> Olivine::dmu_dP(const double &T, const double &P,
                                         const std::vector<double> &x) const
{
  std::vector<double> _dmu_dP = {
  (*_endmembers[0]).dGdP(T, P)};
  return _dmu_dP;
}
//-----------------------------------------------------------------------------
std::vector<double> Olivine::dmu_dxi(const double &T, const double &P,
                                          const std::vector<double> &x,
                                          const int &i) const
{
  std::vector<double> _dx_dxi = Olivine::dx_dxi(x, i);

  std::vector<double> _dmu_dxi = {
  0};
  return _dmu_dxi;
}
//-----------------------------------------------------------------------------
std::vector<double> Olivine::dmu_dci(const double &T, const double &P,
                                          const std::vector<double> &c,
                                          const int &i) const
{
  int C = c.size();
  std::vector<double> _dmu_dci(C);
  std::vector<double> x = Olivine::c_to_x(c);
  std::vector<double> dmu_dxi = Olivine::dmu_dxi(T, P, x, i);
  double dxi_dci = Olivine::dxk_dck(c, i);

  for(int k = 0; k < C; k++)
  {
    _dmu_dci[k] = dmu_dxi[k]*dxi_dci;
  }
  return _dmu_dci;
}
//-----------------------------------------------------------------------------
double Olivine::s(const double &T, const double &P,
                       const std::vector<double> &c) const
{
  double _s = -c[0]*(*_endmembers[0]).dGdT(T, P)/M[0];
  return _s;
}
//-----------------------------------------------------------------------------
double Olivine::alpha(const double &T, const double &P,
                           const std::vector<double> &c) const
{
  double _alpha = c[0]*(*_endmembers[0]).alpha(T, P);
  return _alpha;
}
//-----------------------------------------------------------------------------
double Olivine::Cp(const double &T, const double &P,
                        const std::vector<double> &c) const
{
  double _Cp = c[0]*(*_endmembers[0]).Cp(T, P)/M[0];
  return _Cp;
}
//-----------------------------------------------------------------------------
double Olivine::rho(const double &T, const double &P,
                         const std::vector<double> &c) const
{
  double _rho = 1.0*M[0]/(c[0]*(*_endmembers[0]).V(T, P));
  return _rho;
}
//-----------------------------------------------------------------------------
double Olivine::drho_dT(const double &T, const double &P,
                             const std::vector<double> &c) const
{
  double _drho_dT = -1.0*M[0]*(*_endmembers[0]).dVdT(T, P)/(c[0]*(((*_endmembers[0]).V(T, P))*((*_endmembers[0]).V(T, P))));
  return _drho_dT;
}
//-----------------------------------------------------------------------------
double Olivine::drho_dP(const double &T, const double &P,
                             const std::vector<double> &c) const
{
  double _drho_dP = -1.0*M[0]*(*_endmembers[0]).dVdP(T, P)/(c[0]*(((*_endmembers[0]).V(T, P))*((*_endmembers[0]).V(T, P))));
  return _drho_dP;
}
//-----------------------------------------------------------------------------
double Olivine::drho_dci(const double &T, const double &P,
                              const std::vector<double> &c,
                              const int &i) const
{
  int C = c.size();
  std::vector<double> dc_dci = Olivine::dx_dxi(c, i);
  double _drho_dci = 0.;

  for(int k = 0; k < C; k++)
  {
    _drho_dci += dc_dci[k]*(*_endmembers[k]).V(T, P)/M[k];
  }
  _drho_dci *= -pow(Olivine::rho(T, P, c), 2);
  return _drho_dci;
}
//-----------------------------------------------------------------------------
std::vector<double> Olivine::dx_dxi(const std::vector<double> &x,
                                         const double &i) const
{
  double epsilon = 1.e-4;
  double C = x.size();
  std::vector<double> _dx_dxi(C);
  if((1. - x[i]) > epsilon)
  {
    for(int k = 0; k < C; k++)
    {
      _dx_dxi[k] = -x[k]/(1. - x[i]);
    }
    // Fix dx_k/dx_i = 1 for k = i
    _dx_dxi[i] = 1.;
    }
  else
  {
    std::fill(_dx_dxi.begin(), _dx_dxi.end(), -1./(C - 1.));
    _dx_dxi[i] = 1.;
  }
  return _dx_dxi;
}
//-----------------------------------------------------------------------------
std::vector<double> Olivine::c_to_x(const std::vector<double> &c) const
{
  int C = c.size();

  double sum_c_invM = 0.0;
  for(int i = 0; i < C; i++)
  {
    sum_c_invM += c[i]/M[i];
  }

  std::vector<double> x(C);
  for(int i = 0; i < C; i++)
  {
    x[i] = (c[i]/M[i])/sum_c_invM;
  }
  return x;
}
//-----------------------------------------------------------------------------
std::vector<double> Olivine::x_to_c(const std::vector<double> &x) const
{
  int C = x.size();

  double sum_x_M = 0.0;
  for(int i = 0; i < C; i++)
  {
    sum_x_M += x[i]*M[i];
  }

  std::vector<double> c(C);
  for(int i = 0; i < C; i++)
  {
    c[i] = (x[i]*M[i])/sum_x_M;
  }
  return c;
}
//-----------------------------------------------------------------------------
double Olivine::dxk_dck(const std::vector<double> &c, const int &k) const
{
  double sum_c_invM = 0;
  for(int i = 0; i < c.size(); i++)
  {
    sum_c_invM += c[i]/M[i];
  }

  double inv_Mk_sum_c_invM = (1./M[k])/sum_c_invM;
  double xk = c[k]*inv_Mk_sum_c_invM;
  std::vector<double> dc_dck = Olivine::dx_dxi(c, k);

  double sum_dcdk_invM = 0;
  for(int i = 0; i < c.size(); i++)
  {
    sum_dcdk_invM += dc_dck[i]/M[i];
  }

  double Mk_sum_cinvM_dck = M[k]*sum_dcdk_invM;
  return inv_Mk_sum_c_invM*(1. - xk*Mk_sum_cinvM_dck);
}
//-----------------------------------------------------------------------------
