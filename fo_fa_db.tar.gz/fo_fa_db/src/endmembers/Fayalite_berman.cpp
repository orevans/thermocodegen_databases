#include <math.h>
#include <string>
#include <map>
#include "endmembers/Fayalite_berman.h"

//-----------------------------------------------------------------------------
Fayalite_berman::Fayalite_berman()  
{
  // do nothing;
}
//-----------------------------------------------------------------------------
Fayalite_berman::~Fayalite_berman()
{
  // Do nothing
}
//-----------------------------------------------------------------------------
std::string Fayalite_berman::name()
{
  return "Fayalite_berman";
}
//-----------------------------------------------------------------------------
std::string Fayalite_berman::formula()
{
  return "Fe2SiO4";
}
//-----------------------------------------------------------------------------
double Fayalite_berman::molecular_weight()
{
  return 203.7731;
}
//-----------------------------------------------------------------------------
double Fayalite_berman::G(const double &T, const double &P)
{
  double result = -1.68995e-6*((P)*(P)) + 3.6576999999999997e-8*P*((T)*(T)) + 0.00010109572589999999*P*T + 4.596610234508133*P - 7695.4200000000001*pow(T, 1.0/2.0) - 3.6576999999999997e-8*((T)*(T)) - 248.92812000000001*T*std::log(T) + 1740.8753388763112*T - 1487926.5584324803 + 23184016.0/((T)*(T));
  return result;
}
//-----------------------------------------------------------------------------
double Fayalite_berman::dGdT(const double &T, const double &P)
{
  double result = 7.3153999999999995e-8*P*T + 0.00010109572589999999*P - 7.3153999999999995e-8*T - 248.92812000000001*std::log(T) + 1491.9472188763111 - 46368032.0/((T)*(T)*(T)) - 3847.71/pow(T, 1.0/2.0);
  return result;
}
//-----------------------------------------------------------------------------
double Fayalite_berman::dGdP(const double &T, const double &P)
{
  double result = -3.3799e-6*P + 3.6576999999999997e-8*((T)*(T)) + 0.00010109572589999999*T + 4.596610234508133;
  return result;
}
//-----------------------------------------------------------------------------
double Fayalite_berman::d2GdT2(const double &T, const double &P)
{
  double result = 7.3153999999999995e-8*P - 7.3153999999999995e-8 - 248.92812000000001/T + 139104096.0/((T)*(T)*(T)*(T)) + 1923.855/pow(T, 3.0/2.0);
  return result;
}
//-----------------------------------------------------------------------------
double Fayalite_berman::d2GdTdP(const double &T, const double &P)
{
  double result = 7.3153999999999995e-8*T + 0.00010109572589999999;
  return result;
}
//-----------------------------------------------------------------------------
double Fayalite_berman::d2GdP2(const double &T, const double &P)
{
  double result = -3.3799e-6;
  return result;
}
//-----------------------------------------------------------------------------
double Fayalite_berman::d3GdT3(const double &T, const double &P)
{
  double result = 248.92812000000001/((T)*(T)) - 556416384.0/pow(T, 5) - 2885.7825000000003/pow(T, 5.0/2.0);
  return result;
}
//-----------------------------------------------------------------------------
double Fayalite_berman::d3GdT2dP(const double &T, const double &P)
{
  double result = 7.3153999999999995e-8;
  return result;
}
//-----------------------------------------------------------------------------
double Fayalite_berman::d3GdTdP2(const double &T, const double &P)
{
  double result = 0;
  return result;
}
//-----------------------------------------------------------------------------
double Fayalite_berman::d3GdP3(const double &T, const double &P)
{
  double result = 0;
  return result;
}
//-----------------------------------------------------------------------------
double Fayalite_berman::S(const double& T, const double& P)
{
  double result = -Fayalite_berman::dGdT(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Fayalite_berman::V(const double& T, const double& P)
{
  double result = Fayalite_berman::dGdP(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Fayalite_berman::dVdT(const double& T, const double& P)
{
  double result = Fayalite_berman::d2GdTdP(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Fayalite_berman::dVdP(const double& T, const double& P)
{
  double result = Fayalite_berman::d2GdP2(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Fayalite_berman::Cv(const double& T, const double& P)
{
  double result = -T*Fayalite_berman::d2GdT2(T, P);
  double dVdT = Fayalite_berman::d2GdTdP(T, P);
  double dVdP = Fayalite_berman::d2GdP2(T, P);
  result += T*dVdT*dVdT/dVdP;
  return result;
}
//-----------------------------------------------------------------------------
double Fayalite_berman::Cp(const double& T, const double& P)
{
  double result = -T*Fayalite_berman::d2GdT2(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Fayalite_berman::dCpdT(const double& T, const double& P)
{
  double result = -T*Fayalite_berman::d3GdT3(T, P) - Fayalite_berman::d2GdT2(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Fayalite_berman::alpha(const double& T, const double& P)
{
  double result = Fayalite_berman::d2GdTdP(T, P)/Fayalite_berman::dGdP(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Fayalite_berman::beta(const double& T, const double& P)
{
  double result = -Fayalite_berman::d2GdP2(T, P)/Fayalite_berman::dGdP(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Fayalite_berman::K(const double& T, const double& P)
{
  double result = -Fayalite_berman::dGdP(T,P)/Fayalite_berman::d2GdP2(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Fayalite_berman::Kp(const double& T, const double& P)
{
  double result = -Fayalite_berman::dGdP(T, P)/Fayalite_berman::d2GdP2(T, P);
  return result;
}
//-----------------------------------------------------------------------------
void Fayalite_berman::set_parameter(const std::string& p, const double& val)
{
  *parameters[p] = val;
}
//-----------------------------------------------------------------------------
void Fayalite_berman::get_parameter(const std::string& p)
{
  std::cout << p << " = " << *parameters[p] << std::endl;
}
//-----------------------------------------------------------------------------
void Fayalite_berman::list_active_parameters()
{
  std::cout << "Active parameters: \n" << std::endl;
  for (auto const& x : parameters)
  {
    std::cout << x.first << " = "  << *x.second << std::endl;
  }
}
//-----------------------------------------------------------------------------

