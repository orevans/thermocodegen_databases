#include <math.h>
#include <string>
#include <map>
#include "endmembers/Forsterite_berman.h"

//-----------------------------------------------------------------------------
Forsterite_berman::Forsterite_berman()  
{
  // do nothing;
}
//-----------------------------------------------------------------------------
Forsterite_berman::~Forsterite_berman()
{
  // Do nothing
}
//-----------------------------------------------------------------------------
std::string Forsterite_berman::name()
{
  return "Forsterite_berman";
}
//-----------------------------------------------------------------------------
std::string Forsterite_berman::formula()
{
  return "Mg2SiO4";
}
//-----------------------------------------------------------------------------
double Forsterite_berman::molecular_weight()
{
  return 140.69310000000002;
}
//-----------------------------------------------------------------------------
double Forsterite_berman::G(const double &T, const double &P)
{
  double result = -1.7274079e-6*((P)*(P)) + 3.8857399999999997e-8*P*((T)*(T)) + 0.00010546784658*P*T + 4.331104049082521*P - 8005.0439999999999*pow(T, 1.0/2.0) - 3.8857399999999997e-8*((T)*(T)) - 238.64136999999997*T*std::log(T) + 1737.5770750036631*T - 2177117.3808906907 + 19373880.0/((T)*(T));
  return result;
}
//-----------------------------------------------------------------------------
double Forsterite_berman::dGdT(const double &T, const double &P)
{
  double result = 7.7714799999999994e-8*P*T + 0.00010546784658*P - 7.7714799999999994e-8*T - 238.64136999999997*std::log(T) + 1498.9357050036631 - 38747760.0/((T)*(T)*(T)) - 4002.5219999999999/pow(T, 1.0/2.0);
  return result;
}
//-----------------------------------------------------------------------------
double Forsterite_berman::dGdP(const double &T, const double &P)
{
  double result = -3.4548158000000001e-6*P + 3.8857399999999997e-8*((T)*(T)) + 0.00010546784658*T + 4.331104049082521;
  return result;
}
//-----------------------------------------------------------------------------
double Forsterite_berman::d2GdT2(const double &T, const double &P)
{
  double result = 7.7714799999999994e-8*P - 7.7714799999999994e-8 - 238.64136999999997/T + 116243280.0/((T)*(T)*(T)*(T)) + 2001.261/pow(T, 3.0/2.0);
  return result;
}
//-----------------------------------------------------------------------------
double Forsterite_berman::d2GdTdP(const double &T, const double &P)
{
  double result = 7.7714799999999994e-8*T + 0.00010546784658;
  return result;
}
//-----------------------------------------------------------------------------
double Forsterite_berman::d2GdP2(const double &T, const double &P)
{
  double result = -3.4548158000000001e-6;
  return result;
}
//-----------------------------------------------------------------------------
double Forsterite_berman::d3GdT3(const double &T, const double &P)
{
  double result = 238.64136999999997/((T)*(T)) - 464973120.0/pow(T, 5) - 3001.8914999999997/pow(T, 5.0/2.0);
  return result;
}
//-----------------------------------------------------------------------------
double Forsterite_berman::d3GdT2dP(const double &T, const double &P)
{
  double result = 7.7714799999999994e-8;
  return result;
}
//-----------------------------------------------------------------------------
double Forsterite_berman::d3GdTdP2(const double &T, const double &P)
{
  double result = 0;
  return result;
}
//-----------------------------------------------------------------------------
double Forsterite_berman::d3GdP3(const double &T, const double &P)
{
  double result = 0;
  return result;
}
//-----------------------------------------------------------------------------
double Forsterite_berman::S(const double& T, const double& P)
{
  double result = -Forsterite_berman::dGdT(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Forsterite_berman::V(const double& T, const double& P)
{
  double result = Forsterite_berman::dGdP(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Forsterite_berman::dVdT(const double& T, const double& P)
{
  double result = Forsterite_berman::d2GdTdP(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Forsterite_berman::dVdP(const double& T, const double& P)
{
  double result = Forsterite_berman::d2GdP2(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Forsterite_berman::Cv(const double& T, const double& P)
{
  double result = -T*Forsterite_berman::d2GdT2(T, P);
  double dVdT = Forsterite_berman::d2GdTdP(T, P);
  double dVdP = Forsterite_berman::d2GdP2(T, P);
  result += T*dVdT*dVdT/dVdP;
  return result;
}
//-----------------------------------------------------------------------------
double Forsterite_berman::Cp(const double& T, const double& P)
{
  double result = -T*Forsterite_berman::d2GdT2(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Forsterite_berman::dCpdT(const double& T, const double& P)
{
  double result = -T*Forsterite_berman::d3GdT3(T, P) - Forsterite_berman::d2GdT2(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Forsterite_berman::alpha(const double& T, const double& P)
{
  double result = Forsterite_berman::d2GdTdP(T, P)/Forsterite_berman::dGdP(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Forsterite_berman::beta(const double& T, const double& P)
{
  double result = -Forsterite_berman::d2GdP2(T, P)/Forsterite_berman::dGdP(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Forsterite_berman::K(const double& T, const double& P)
{
  double result = -Forsterite_berman::dGdP(T,P)/Forsterite_berman::d2GdP2(T, P);
  return result;
}
//-----------------------------------------------------------------------------
double Forsterite_berman::Kp(const double& T, const double& P)
{
  double result = -Forsterite_berman::dGdP(T, P)/Forsterite_berman::d2GdP2(T, P);
  return result;
}
//-----------------------------------------------------------------------------
void Forsterite_berman::set_parameter(const std::string& p, const double& val)
{
  *parameters[p] = val;
}
//-----------------------------------------------------------------------------
void Forsterite_berman::get_parameter(const std::string& p)
{
  std::cout << p << " = " << *parameters[p] << std::endl;
}
//-----------------------------------------------------------------------------
void Forsterite_berman::list_active_parameters()
{
  std::cout << "Active parameters: \n" << std::endl;
  for (auto const& x : parameters)
  {
    std::cout << x.first << " = "  << *x.second << std::endl;
  }
}
//-----------------------------------------------------------------------------

